﻿namespace SG.PO.Chino.DataModels.Outputmodels
{
    public class POSkusOutput
    {
        public string ItemName { get; set; }
        public string OrderQty { get; set; }               
    }
}
