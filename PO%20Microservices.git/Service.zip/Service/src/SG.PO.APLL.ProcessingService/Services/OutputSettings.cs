﻿namespace SG.PO.APLL.ProcessingService.Services
{
    public class OutputSettings
    {
        public string Type { get; set; }        
        public string OutputFilePath { get; set; }
        public string OutputFileNameDateFormat { get; set; }
    }
}
