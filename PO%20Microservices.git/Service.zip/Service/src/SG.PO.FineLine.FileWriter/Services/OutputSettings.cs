﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SG.PO.FineLine.FileWriter.Services
{
    public class OutputSettings
    {
        public string Type { get; set; }
        public string ConfigFile { get; set; }
        public string OutputFilePath { get; set; }
    }
}
