﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace SG.PO.Chino.ProcessingService.Outputmodels
{
    public class CustomFields
    {
        public string CustomField { get; set; }
    }
}
