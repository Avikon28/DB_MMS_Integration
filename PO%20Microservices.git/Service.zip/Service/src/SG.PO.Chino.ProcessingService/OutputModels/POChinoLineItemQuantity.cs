﻿namespace SG.PO.Chino.ProcessingService.Outputmodels
{
    public class POChinoLineItemQuantity
    {
        public string OrderQty { get; set; }
        public string QtyUOM { get; set; }
    }
}
