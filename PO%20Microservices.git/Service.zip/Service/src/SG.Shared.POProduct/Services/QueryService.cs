﻿namespace SG.Shared.POProduct.Services
{
    public class QueryService
    {
        public string QueryServiceAddress { get; set; }
    }
}
