﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SG.PO.FineLine.CommandService.Core.Services
{
    public class QueryServiceEnpoint
    {
        public string QueryServiceAddress { get; set; }
    }
}
