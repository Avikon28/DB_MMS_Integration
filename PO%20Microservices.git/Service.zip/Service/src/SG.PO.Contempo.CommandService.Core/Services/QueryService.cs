﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SG.PO.Contempo.CommandService.Core.Services
{
    public class QueryServiceEnpoint
    {
        public string QueryServiceAddress { get; set; }
    }
}
